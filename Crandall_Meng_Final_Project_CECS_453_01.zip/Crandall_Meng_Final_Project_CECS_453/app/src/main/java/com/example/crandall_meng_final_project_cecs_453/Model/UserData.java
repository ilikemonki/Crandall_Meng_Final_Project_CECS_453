package com.example.crandall_meng_final_project_cecs_453.Model;

import android.content.Context;
import android.database.Cursor;

public class UserData {
    /*
        protected static final String ENSURE_USER_TABLE = "create TABLE IF NOT EXISTS login(" +
            "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "username TEXT NOT NULL, " +
            "password TEXT NOT NULL, " +
            "email TEXT NOT NULL, " +
            "phone TEXT NOT null, " +
            "age INTEGER)";
     */

    public static String validateUser(Context ctx, String username, String password) {
        try(Database database = new Database(ctx)) {

            Cursor cursor = database.db.query("login",
                    new String[] {"username", "password"},
                    "username=?",
                    new String[] {username},
                    null, null, null, null);

            if(cursor.moveToFirst()) {
                if(cursor.getString(cursor.getColumnIndex("password")).equals(password)) { return null; }

                while(cursor.moveToNext()) {
                    if(cursor.getString(cursor.getColumnIndex("password")).equals(password)) { return null; }
                }
            }

            return "Invalid username/password combination";

        } catch(Exception e) {
            return "Failed to access database.";
        }
    }

    public static String signupUser(Context ctx, String username, String password, String email, String phone, String age) {
        try(Database database = new Database(ctx)) {
            if(validateUser(ctx, username, password) == null) { return "User already signed up."; }

            String query = "INSERT INTO login (username, password, email, phone, age) VALUES(" +
                    "'" + username + "', " +
                    "'" + password + "', " +
                    "'" + email + "', " +
                    "'" + phone + "', " +
                    "'" + age + "')";

            database.db.execSQL(query);

            return null;
        } catch(Exception e) {
            return "Failed to access database.";
        }
    }
}
